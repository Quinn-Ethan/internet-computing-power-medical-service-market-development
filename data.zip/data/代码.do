///基准代码

reghdfe msmd icp ,ab(id year) vce (cluster id )
outreg2 using results.doc,replace sdec(3) bdec(3)   ctitle( msmd )
reghdfe msmd icp ind to ec itsr  ,ab(id year) vce (cluster id )
outreg2 using results.doc,append sdec(3) bdec(3)   ctitle( msmd )

///截面相关
* 设置面板
xtset id year

* 截面相关
 xtcd msmd icpi ind od ec itsr
 
/////单位根

*=============================================
* 一、面板设定
*=============================================
xtset id year

*=============================================
* 二、CIPS 水平值单位根检验
*=============================================
xtcips msmd, maxlags(1) bglags(1)
xtcips icpi, maxlags(1) bglags(1)
xtcips ind,  maxlags(1) bglags(1)
xtcips od,   maxlags(1) bglags(1)
xtcips ec,   maxlags(1) bglags(1)
xtcips itsr, maxlags(1) bglags(1)

*=============================================
* 三、CIPS 一阶差分单位根检验
*=============================================
xtcips D.msmd, maxlags(1) bglags(1)
xtcips D.icpi, maxlags(1) bglags(1)
xtcips D.ind,  maxlags(1) bglags(1)
xtcips D.od,   maxlags(1) bglags(1)
xtcips D.ec,   maxlags(1) bglags(1)
xtcips D.itsr, maxlags(1) bglags(1)

///////协整检验
xtpedroni msmd icpi ind od ec itsr

/////* 两步系统GMM
xtabond2 msmd L.msmd icpi ///
 ind od ec itsr i.year, ///
gmm(L.msmd icpi, lag(4 7) collapse) ///
iv(ind od ec itsr i.year) ///
twostep robust small

////bootstrap间接中介
capture program drop med_twfe
program define med_twfe, rclass

    * 路径 a：解释变量x -> 中介变量m
    reghdfe   hif icpi ind od ec itsr, absorb(id year)
    scalar a = _b[icpi]

    * 路径 b 和直接效应 c'
    reghdfe msmd  icpi hif ind od ec itsr, absorb(id year)
    scalar b = _b[hif]
    scalar cprime = _b[icpi]

    * 间接效应、直接效应
    return scalar ind_eff = a * b
    return scalar dir_eff = cprime
    return scalar total_eff = cprime + a * b

end

bootstrap r(ind_eff) r(dir_eff) r(total_eff) , reps(1000) seed(202606): ///
    med_twfe
	
	
	/////分组异质性代码
	
reghdfe msmd icp ind to ec itsr if region == 1 ,ab(id year) vce (cluster id )
	outreg2 using yizhixing.doc,replace sdec(3) bdec(3)   ctitle( msmd )
	reghdfe msmd icp ind to ec itsr if region == 2 ,ab(id year) vce (cluster id )
	outreg2 using yizhixing.doc,append sdec(3) bdec(3)   ctitle( msmd )
	reghdfe msmd icp ind to ec itsr if region == 3 ,ab(id year) vce (cluster id )
	outreg2 using yizhixing.doc,append sdec(3) bdec(3)   ctitle( msmd )
	
	
	
	
	
	
