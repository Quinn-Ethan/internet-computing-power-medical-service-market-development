*============================================================
* 新版医疗保健市场系数 medical_market
* 不分层熵值法
* 年度熵权取平均 + 全样本统一标准化
*============================================================

clear matrix
set more off

*============================================================
* 1. 自动识别变量并重命名
*============================================================

capture program drop autorename

program define autorename
    args keyword newname

    * 如果已经存在目标变量名，则跳过
    capture confirm variable `newname'

    if _rc {

        quietly lookfor "`keyword'"
        local oldname `r(varlist)'
        local number : word count `oldname'

        if `number' != 1 {
            display as error "没有唯一找到变量：`keyword'"
            display as error "请运行 describe 检查实际变量名"
            exit 111
        }

        rename `oldname' `newname'
    }
end


*------------------------------------------------------------
* 基础变量
*------------------------------------------------------------

autorename 年份 year

*------------------------------------------------------------
* 六个医疗保健市场指标
*------------------------------------------------------------

* 需求与市场规模
autorename 人均全国医疗保健支出元       med_spend
autorename 人均卫生总费用         health_cost_pc

* 服务供给能力
autorename 注册占比               registered_pc
autorename 基层医疗卫生机构数     primary_fac_pc

* 市场利用与产出
autorename 家庭卫生服务人次数     family_service_pc
autorename 基层机构诊疗人次       primary_visit_pc


*============================================================
* 2. 六项指标
*============================================================

local vars med_spend ///
           health_cost_pc ///
           registered_pc ///
           primary_fac_pc ///
           family_service_pc ///
           primary_visit_pc


* 检查变量
confirm variable year `vars'


*============================================================
* 3. 如果没有 id，则根据省份生成 id
*============================================================

capture confirm variable id

if _rc {

    capture confirm variable province

    if !_rc {
        encode province, gen(id)
    }

    else {
        display as error "没有找到 id 或 province"
        exit 111
    }
}


*============================================================
* 4. 检查面板数据
*============================================================

isid id year

sort year id

* 删除上次运行产生的变量
capture drop ew_*
capture drop medical_market


*============================================================
* 5. 每年分别进行正向 Min-Max 标准化
*    并计算信息冗余度 d
*============================================================

bysort year: gen int ew_n = _N

local dlist


foreach x of local vars {

    *--------------------------------------------------------
    * 每年最大值、最小值
    *--------------------------------------------------------

    bysort year: egen double ew_min_`x' = min(`x')
    bysort year: egen double ew_max_`x' = max(`x')


    *--------------------------------------------------------
    * 正向 Min-Max 标准化
    *
    * Zij = (Xij - minX)/(maxX-minX)
    *--------------------------------------------------------

    gen double ew_a_`x' = ///
        cond(ew_max_`x' > ew_min_`x', ///
        (`x' - ew_min_`x') / ///
        (ew_max_`x' - ew_min_`x'), 0)


    *--------------------------------------------------------
    * 指标比重 p
    *--------------------------------------------------------

    bysort year: egen double ew_sum_`x' = ///
        total(ew_a_`x')

    gen double ew_p_`x' = ///
        cond(ew_sum_`x' > 0, ///
        ew_a_`x' / ew_sum_`x', 0)


    *--------------------------------------------------------
    * p × ln(p)
    *
    * p=0 时定义为0
    *--------------------------------------------------------

    gen double ew_plnp_`x' = ///
        cond(ew_p_`x' > 0, ///
        ew_p_`x' * ln(ew_p_`x'), 0)

    bysort year: egen double ew_lsum_`x' = ///
        total(ew_plnp_`x')


    *--------------------------------------------------------
    * 信息冗余度
    *
    * d = 1 - e
    *--------------------------------------------------------

    gen double ew_d_`x' = ///
        cond(ew_sum_`x' > 0, ///
        1 + ew_lsum_`x' / ln(ew_n), 0)


    local dlist `dlist' ew_d_`x'
}


*============================================================
* 6. 计算每个年度的熵权
*============================================================

* 六项指标的信息冗余度之和
egen double ew_D = rowtotal(`dlist')

* 每个年份只取一条观测
egen byte ew_tag = tag(year)


*============================================================
* 7. 各年度熵权取平均
*    得到2014—2023统一固定权重
*============================================================

foreach x of local vars {

    * 年度权重
    gen double ew_w_`x' = ///
        cond(ew_D > 0, ew_d_`x' / ew_D, 0)


    *--------------------------------------------------------
    * 对2014—2023年度权重求平均
    *--------------------------------------------------------

    quietly summarize ew_w_`x' ///
        if ew_tag == 1, meanonly

    scalar W_`x' = r(mean)


    *--------------------------------------------------------
    * 全样本统一 Min-Max 标准化
    *
    * 注意：
    * 这里不是按年度标准化
    * 是300个省份—年份观测统一标准化
    *--------------------------------------------------------

    quietly summarize `x', meanonly

    gen double ew_z_`x' = ///
        cond(r(max) > r(min), ///
        (`x' - r(min)) / ///
        (r(max) - r(min)), 0)
}


*============================================================
* 8. 六项指标不分层直接合成
*============================================================

gen double medical_market = 0


foreach x of local vars {

    replace medical_market = ///
        medical_market + ///
        scalar(W_`x') * ew_z_`x'
}


*============================================================
* 9. 调整为0—100区间
*============================================================

replace medical_market = 100 * medical_market

label variable medical_market ///
    "医疗保健市场系数：不分层熵值法"


*============================================================
* 10. 查看最终医疗保健市场系数
*============================================================

summarize medical_market, detail

list id year medical_market in 1/20


*============================================================
* 11. 输出六项指标最终权重
*============================================================

display " "
display "=================================================="
display "六项医疗保健指标最终平均熵权"
display "=================================================="


foreach x of local vars {

    display "`x' 权重 = " ///
        %9.6f scalar(W_`x')
}


display " "
display "权重合计 = " ///
    %9.6f ///
    (scalar(W_med_spend) + ///
     scalar(W_health_cost_pc) + ///
     scalar(W_registered_pc) + ///
     scalar(W_primary_fac_pc) + ///
     scalar(W_family_service_pc) + ///
     scalar(W_primary_visit_pc))


*============================================================
* 12. 删除熵值法中间变量
*============================================================

drop ew_*


*============================================================
* 13. 最终检查
*============================================================

summarize medical_market

list id year medical_market in 1/10