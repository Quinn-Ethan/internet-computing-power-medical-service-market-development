*******************************************************
* 省级IDC许可证有效期口径生成代码（简化复现版）
*
* 运行需要：
* 1. 原始数据.xlsx
* 2. 省级IDC_地点省份映射.xlsx
*
* 计数单位：IDC许可证编号 × 省份
* 主指标：编号年份 <= 观察年份 <= 有效期截止年份
*******************************************************

version 17.0
clear all
set more off
unicode encoding set utf8

* 文件位置改变时，只需修改下面三行
global rawfile "D:/Desktop/省级idc/726/尝试/原始数据.xlsx"
global mapfile "D:/Desktop/省级idc/726/尝试/省级IDC_地点省份映射.xlsx"
global outdir  "D:/Desktop/省级idc/729尝试codex/年内有效期代码"

capture mkdir "$outdir"
capture log close
log using "$outdir/省级IDC有效期口径_简化版运行日志.txt", text replace

tempfile mapdata provincelist license_province
tempfile active_counts new_counts expire_counts years

*******************************************************
* 一、读取地点—省份映射
*******************************************************

import excel using "$mapfile", sheet("地点映射") clear allstring
rename A location
rename B province
rename C include_flag
drop in 1

replace location = ustrtrim(subinstr(location, char(9), "", .))
replace province = ustrtrim(province)
keep if include_flag == "1" & location != ""

gen long map_order = _n
preserve
    sort province map_order
    by province: keep if _n == 1
    sort map_order
    gen byte province_order = _n
    keep province province_order
    save `provincelist', replace
restore

keep location province
save `mapdata', replace

*******************************************************
* 二、读取许可证并整理编号年份、有效期
*******************************************************

import excel using "$rawfile", sheet("Sheet2") clear allstring
rename A license
rename B company
rename C bus_type
rename D scope
rename E expire_date_raw
drop in 1

foreach v in license company bus_type scope expire_date_raw {
    replace `v' = ustrtrim(`v')
}
duplicates drop license company bus_type scope expire_date_raw, force

replace scope = ustrregexra(scope, "：", ":")
replace scope = ustrregexra(scope, "，", ",")

gen int issue_year = real(ustrregexs(1)) ///
    if ustrregexm(license, "-([0-9]{4})")

* 同时兼容日期字符串和Excel日期序列值
gen double expire_date = daily(substr(expire_date_raw, 1, 10), "YMD")
replace expire_date = daily(substr(expire_date_raw, 1, 10), "DMY") ///
    if missing(expire_date)
replace expire_date = real(expire_date_raw) + td(30dec1899) ///
    if missing(expire_date) & ///
    ustrregexm(expire_date_raw, "^[0-9]+([.][0-9]+)?$")
format expire_date %tdCCYY-NN-DD
gen int expire_year = year(expire_date)

keep if inrange(issue_year, 2001, 2025)
keep if ustrpos(scope, "互联网数据中心业务") > 0
assert !missing(issue_year)
assert !missing(expire_date)
assert expire_year >= issue_year

*******************************************************
* 三、拆分IDC地点并映射到省份
*******************************************************

gen strL idc_locations = usubstr(scope, ///
    ustrpos(scope, "互联网数据中心业务:") + ///
    ustrlen("互联网数据中心业务:"), .)
replace idc_locations = ustrregexra( ///
    idc_locations, ",[^,]*业务[^,:]*:.*$", "")

gen long source_id = _n
gen str2045 idc_locations_s = idc_locations
split idc_locations_s, parse(",") gen(loc)

keep source_id license issue_year expire_date expire_year loc*
reshape long loc, i(source_id) j(location_no)
rename loc location

replace location = ustrtrim(subinstr(location, char(9), "", .))
drop if location == "" | location == "全国"

merge m:1 location using `mapdata', keep(match) nogen

* 同一许可证在同一省覆盖多个地点只计1次；
* 若存在更新记录，保留该许可证在该省最晚的有效期
sort license province expire_date
by license province: keep if _n == _N
keep license province issue_year expire_date expire_year
save `license_province', replace

*******************************************************
* 四、计算年度有效、新增和到期数量
*******************************************************

use `license_province', clear
gen int active_start = max(issue_year, 2001)
gen int active_end = min(expire_year, 2025)
drop if active_end < active_start

gen int active_years = active_end - active_start + 1
expand active_years
bysort license province: gen int year = active_start + _n - 1

gen byte active_during_year = 1
gen byte active_at_yearend = expire_date >= mdy(12, 31, year)

collapse (sum) ///
    idc_active_during_year = active_during_year ///
    idc_active_at_yearend = active_at_yearend, ///
    by(province year)
save `active_counts', replace

use `license_province', clear
contract province issue_year, freq(idc_new)
rename issue_year year
save `new_counts', replace

use `license_province', clear
keep if inrange(expire_year, 2001, 2025)
contract province expire_year, freq(idc_expiring)
rename expire_year year
save `expire_counts', replace

*******************************************************
* 五、生成31省、2001—2025年平衡面板
*******************************************************

clear
set obs 25
gen int year = 2000 + _n
save `years', replace

use `provincelist', clear
cross using `years'
merge 1:1 province year using `active_counts', nogen
merge 1:1 province year using `new_counts', nogen
merge 1:1 province year using `expire_counts', nogen

foreach v in idc_active_during_year idc_active_at_yearend ///
             idc_new idc_expiring {
    replace `v' = 0 if missing(`v')
}

sort province_order year
by province_order: gen long idc_ever_approved = sum(idc_new)
gen byte research_sample_year = inrange(year, 2014, 2023)

rename province 省份
rename province_order 省份顺序
rename year 年份
rename idc_active_during_year 年度内有效IDC许可证数
rename idc_active_at_yearend 年末有效IDC许可证数
rename idc_new 当年新获批IDC许可证数
rename idc_expiring 当年到期IDC许可证数
rename idc_ever_approved 累计获批IDC许可证数
rename research_sample_year 研究样本年份

order 省份顺序 省份 年份 ///
    年度内有效IDC许可证数 年末有效IDC许可证数 ///
    当年新获批IDC许可证数 当年到期IDC许可证数 ///
    累计获批IDC许可证数 研究样本年份
sort 省份顺序 年份

save "$outdir/省级IDC_有效期口径面板.dta", replace
export excel using "$outdir/省级IDC_有效期口径面板.xlsx", ///
    sheet("省级年度面板") firstrow(variables) replace

*******************************************************
* 六、写入口径说明
*******************************************************

clear
set obs 8
gen str40 项目 = ""
gen str244 说明 = ""
replace 项目 = "计数单位" in 1
replace 说明 = "IDC许可证编号×省份；同一许可证覆盖同一省多个城市只计1次。" in 1
replace 项目 = "主指标" in 2
replace 说明 = "年度内有效IDC许可证数：编号年份≤观察年份≤到期年份。" in 2
replace 项目 = "稳健指标" in 3
replace 说明 = "年末有效IDC许可证数：截至观察年12月31日仍未到期。" in 3
replace 项目 = "起始日期限制" in 4
replace 说明 = "原始数据无准确发证日，以许可证编号中的年份作为生效起始年。" in 4
replace 项目 = "到期年份处理" in 5
replace 说明 = "主指标纳入到期年份；年末口径按精确截止日期判断。" in 5
replace 项目 = "跨省许可证" in 6
replace 说明 = "许可证覆盖多个省份时，在每个覆盖省份各计1次。" in 6
replace 项目 = "全国记录" in 7
replace 说明 = "覆盖地点仅为“全国”的记录不纳入省级统计。" in 7
replace 项目 = "研究样本年份" in 8
replace 说明 = "研究样本年份=1表示2014—2023年。" in 8
export excel using "$outdir/省级IDC_有效期口径面板.xlsx", ///
    sheet("口径说明", replace) firstrow(variables)

log close
exit, clear
